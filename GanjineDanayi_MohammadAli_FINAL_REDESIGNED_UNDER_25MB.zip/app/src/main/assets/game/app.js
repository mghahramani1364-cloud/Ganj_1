(()=>{'use strict';
const $=id=>document.getElementById(id), main=$('main'), toastEl=$('toast'), modalHost=$('modalHost');
const CITIES=[
{id:'shiraz',name:'شیراز',book:'ریاضی سوم',code:'C305',title:'شهر رازهای عددی',landmark:'تخت جمشید',pos:[51,68],desc:'از باغ‌های دانایی تا تخت جمشید، راز عددها را کشف کن.'},
{id:'mashhad',name:'مشهد',book:'هدیه‌های آسمان سوم',code:'C302',title:'شهر مهربانی',landmark:'حرم مطهر امام رضا (ع)',pos:[78,30],desc:'با مهربانی، دوستی و درس‌های زندگی پیش برو.'},
{id:'qom',name:'قم',book:'نگارش فارسی سوم',code:'C304',title:'شهر واژه‌های زیبا',landmark:'گنبد و گلدسته',pos:[57,48],desc:'واژه‌ها را کنار هم بگذار و نوشته‌های زیبا بساز.'},
{id:'isfahan',name:'اصفهان',book:'علوم تجربی سوم',code:'C306',title:'شهر کشف و آزمایش',landmark:'سی‌وسه‌پل',pos:[58,60],desc:'با مشاهده و پرسش، شگفتی‌های جهان را بشناس.'},
{id:'tabriz',name:'تبریز',book:'فارسی سوم',code:'C303',title:'شهر قصه و خواندن',landmark:'بازار تاریخی',pos:[30,22],desc:'قصه‌ها را بخوان، معنی واژه‌ها را پیدا کن.'},
{id:'ahvaz',name:'اهواز',book:'مطالعات اجتماعی سوم',code:'C307',title:'شهر رود و همسایگی',landmark:'پل روی کارون',pos:[31,73],desc:'با مردم، شهرها، نقشه‌ها و زندگی اجتماعی آشنا شو.'},
{id:'sanandaj',name:'سنندج',book:'آموزش قرآن سوم',code:'C301',title:'شهر نور و تلاوت',landmark:'کوهستان زاگرس',pos:[35,40],desc:'با آرامش، روخوانی و تمرین قرآن را بیاموز.'}
];
const BOOK_NAMES={'C301':'آموزش قرآن سوم','C302':'هدیه‌های آسمان سوم','C303':'فارسی سوم','C304':'نگارش فارسی سوم','C305':'ریاضی سوم','C306':'علوم تجربی سوم','C307':'مطالعات اجتماعی سوم'};
const BANK=window.GDM_BANK;
if(!BANK||!Array.isArray(BANK.questions)||BANK.questions.length!==10320){main.innerHTML='<section class="panel"><h2>خطا در بارگذاری بانک سؤال</h2><p>فایل بانک سؤال کامل بارگذاری نشده است. برنامه را ببند و بستهٔ کامل پروژه را بررسی کن.</p></section>';return;}
const unitsByCode={},unitById={},questionsByUnit={};
BANK.units.forEach(u=>{unitById[u.unit_id]=u;(unitsByCode[u.book_code] ||= []).push(u);});
BANK.questions.forEach(q=>(questionsByUnit[q.unit_id] ||= []).push(q));
let current={screen:'map',city:null,unit:null,stage:1,items:[],index:0,answers:[],feedback:false,from:'map'};
let toastTimer=null;
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function showToast(s){toastEl.textContent=s;toastEl.classList.remove('hidden');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastEl.classList.add('hidden'),3300);}
function getProgress(){try{return JSON.parse(localStorage.getItem('gdm_progress_v3')||'{}')}catch(e){return {}}}
function saveProgress(p){localStorage.setItem('gdm_progress_v3',JSON.stringify(p));}
function unitProgress(id){return getProgress()[id]||{unlocked:1,done:{},best:{}};}
function completedStages(){let p=getProgress(),n=0;Object.values(p).forEach(x=>n+=Object.keys(x.done||{}).length);return n;}
function totalStars(){let p=getProgress(),n=0;Object.values(p).forEach(x=>Object.values(x.best||{}).forEach(v=>{n+=Math.floor((v||0)/20)}));return n;}
function cityByCode(code){return CITIES.find(c=>c.code===code)||CITIES[0]}
function cityUnits(city){return (unitsByCode[city.code]||[]).slice().sort((a,b)=>a.unit_no-b.unit_no)}
function bookUnitCount(city){return cityUnits(city).length}
function imgCity(c){return `images/cities/${c.id}.svg`}
function imgLesson(u){return `images/lessons/${u.unit_id}.svg`}
function imgStage(n){return `images/stages/stage-${String(n).padStart(2,'0')}.svg`}
function header(title,sub=''){return `<div class="panel"><h2 class="section-title">${esc(title)}</h2>${sub?`<p class="subtext">${esc(sub)}</p>`:''}</div>`}
function renderMap(){current.screen='map';current.city=null;current.unit=null;
const pins=CITIES.map(c=>`<button class="city-pin ${c.id==='shiraz'?'central':''}" style="left:${c.pos[0]}%;top:${c.pos[1]}%" data-city="${c.id}" aria-label="ورود به شهر ${esc(c.name)}"><img src="${imgCity(c)}" alt=""><strong>${esc(c.name)}</strong><small>${esc(c.book)}</small></button>`).join('');
main.innerHTML=`<section class="view"><div class="hero"><div class="hero-copy"><div class="ornament">✦ ✧ ✦</div><h2>به سرزمین دانایی خوش آمدی!</h2><p>هفت شهر، هفت کتاب درسی؛ هر محله یک درس و هر مرحله فرصتی تازه برای یادگیری.</p><button class="btn primary" id="showCities">ورود به شهرها</button></div><img class="hero-art" src="images/ui/intro.svg" alt="قصر دانایی"></div>
<div class="map-layout"><div class="map-wrap"><svg class="map-svg" viewBox="0 0 500 560" preserveAspectRatio="xMidYMid meet" aria-label="نقشهٔ تصویری سرزمین ایران"><defs><linearGradient id="sea" x2="0" y2="1"><stop stop-color="#b8e9f7"/><stop offset="1" stop-color="#e4f6e7"/></linearGradient><linearGradient id="land" x2="0.8" y2="1"><stop stop-color="#c9e7a4"/><stop offset="1" stop-color="#74bd8c"/></linearGradient><filter id="mapshadow"><feDropShadow dx="0" dy="5" stdDeviation="5" flood-color="#22506a" flood-opacity=".28"/></filter></defs><rect width="500" height="560" fill="url(#sea)"/><path d="M175 38L220 26 252 43 280 40 306 69 336 91 356 116 390 132 407 158 396 190 422 219 411 248 426 277 408 307 384 330 380 360 355 382 338 411 307 423 286 453 259 463 232 448 211 432 181 433 160 411 132 398 121 369 98 351 86 321 97 292 80 267 91 240 82 213 100 185 117 161 124 131 146 107 157 77Z" fill="url(#land)" stroke="#3b8c72" stroke-width="5" filter="url(#mapshadow)"/><path d="M154 91L190 110 211 139 202 160 226 183 216 207 244 224 232 250 256 270 249 297 276 318 263 345 288 364 280 391" fill="none" stroke="#f6e2a1" stroke-width="8" stroke-linecap="round"/><path d="M154 91L190 110 211 139 202 160 226 183 216 207 244 224 232 250 256 270 249 297 276 318 263 345 288 364 280 391" fill="none" stroke="#fff7d2" stroke-width="3" stroke-linecap="round"/><g fill="#f8f4d5" opacity=".85"><path d="M125 178l20-28 15 23-15 19z"/><path d="M318 125l18-25 17 26-17 20z"/><path d="M327 344l18-26 18 28-19 18z"/></g><g fill="#e5f3d4" stroke="#6cae82" stroke-width="2"><path d="M155 250l17-16 17 16-17 16z"/><path d="M285 210l17-16 17 16-17 16z"/><path d="M185 350l17-16 17 16-17 16z"/></g><text x="248" y="510" text-anchor="middle" font-size="15" font-weight="bold" fill="#2d7894">دریای دانایی</text></svg><div class="map-label">نقشهٔ سرزمین ایران</div>${pins}</div>
<div class="city-info"><div class="city-feature"><img src="images/cities/shiraz.svg" alt="تصویر شهر شیراز"><div class="city-feature-copy"><h3>شیراز؛ شهر آغاز دانایی</h3><p class="subtext">شهر مرکزی سرزمین ماست. از اینجا می‌توانی وارد هر یک از هفت شهر شوی.</p><button class="btn primary" id="enterShiraz">ورود به شیراز</button></div></div><div class="panel" style="margin:0"><div class="stats"><div class="stat"><strong>${BANK.questions.length.toLocaleString('fa-IR')}</strong><small>سؤال در بانک</small></div><div class="stat"><strong>${BANK.units.length.toLocaleString('fa-IR')}</strong><small>محله / درس</small></div><div class="stat"><strong>${completedStages().toLocaleString('fa-IR')}</strong><small>مرحلهٔ تمام‌شده</small></div></div><div class="guide-strip"><img src="images/cities/mashhad.svg" alt="راهنمای دانایی"><p><b>خانم دهقانی‌زاده:</b><br>هر شهر فقط کتاب خودش را دارد. با آرامش درس بخوان و قدم‌به‌قدم پیش برو.</p></div><div class="notice">برای هر محله، مرحلهٔ اول از ابتدا باز است. مراحل بعدی همان محله پس از پایان مرحلهٔ قبلی باز می‌شوند.</div></div></div></div>
<div class="panel"><h2 class="section-title">هفت شهر دانایی</h2><p class="subtext">برای دیدن محله‌ها و درس‌های هر کتاب، شهر موردنظرت را انتخاب کن.</p><div class="city-grid">${CITIES.map(c=>`<article class="city-card"><img src="${imgCity(c)}" alt="نمای تصویری شهر ${esc(c.name)}"><div class="body"><h3>${esc(c.name)} — ${esc(c.book)}</h3><p>${esc(c.desc)}</p><span class="pill">${bookUnitCount(c).toLocaleString('fa-IR')} محله / درس</span><button class="btn primary" data-city="${c.id}">ورود به شهر</button></div></article>`).join('')}</div></div></section>`;
$('showCities').onclick=()=>document.querySelector('.city-grid').scrollIntoView({behavior:'smooth',block:'start'});$('enterShiraz').onclick=()=>renderCity('shiraz');
main.querySelectorAll('[data-city]').forEach(b=>b.addEventListener('click',()=>renderCity(b.dataset.city)));
}
function renderCity(id){const c=CITIES.find(x=>x.id===id);if(!c)return;current.screen='city';current.city=c;current.unit=null;const units=cityUnits(c);const doneCount=units.reduce((n,u)=>n+Object.keys(unitProgress(u.unit_id).done||{}).length,0);
main.innerHTML=`<section class="view"><div class="row" style="margin-top:12px"><button class="btn ghost" id="backMap">← بازگشت به نقشه</button><button class="btn ghost" id="musicFromCity">♫ موسیقی</button></div><div class="city-banner" style="margin-top:12px"><div><span class="pill">شهر ${esc(c.name)}</span><h2>${esc(c.title)}</h2><p>${esc(c.desc)}<br>کتاب این شهر: <b>${esc(c.book)}</b></p><div class="progress-track"><span style="width:${Math.min(100,doneCount/(units.length*20)*100)}%"></span></div><small>پیشرفت این شهر: ${doneCount.toLocaleString('fa-IR')} از ${(units.length*20).toLocaleString('fa-IR')} مرحله</small></div><img src="${imgCity(c)}" alt="نمای شهر ${esc(c.name)}"></div><div class="panel"><h2 class="section-title">محله‌ها و درس‌های شهر ${esc(c.name)}</h2><p class="subtext">هر محله مربوط به یک درس/واحد از کتاب ${esc(c.book)} است. مرحلهٔ اول همهٔ محله‌ها باز است.</p><input id="unitSearch" class="searchbar" placeholder="جست‌وجو در عنوان درس‌ها…" aria-label="جست‌وجوی درس"><div class="unit-list" id="unitList">${units.map(u=>unitCard(u,c)).join('')}</div><div class="notice">این شهر فقط سؤال‌های کتاب «${esc(c.book)}» را نمایش می‌دهد؛ آزمون‌ها با کتاب‌های دیگر مخلوط نمی‌شوند.</div></div></section>`;
$('backMap').onclick=renderMap;$('musicFromCity').onclick=()=>{$('musicPlayer').classList.remove('hidden');$('musicReopen').classList.add('hidden');};$('unitSearch').addEventListener('input',e=>{const q=e.target.value.trim().toLowerCase();$('unitList').querySelectorAll('.unit-card').forEach(el=>el.classList.toggle('hidden',!el.dataset.search.includes(q)));});
main.querySelectorAll('[data-unit]').forEach(b=>b.addEventListener('click',()=>renderUnit(b.dataset.unit)));
}
function unitCard(u,c){const p=unitProgress(u.unit_id),done=Object.keys(p.done||{}).length,percent=Math.round(done/20*100);return `<article class="unit-card" data-search="${esc((u.title+' '+u.unit_no+' '+c.name).toLowerCase())}"><img src="${imgLesson(u)}" alt="تصویر محله ${esc(u.title)}"><div><h3>محلهٔ ${u.unit_no.toLocaleString('fa-IR')}: ${esc(u.title)}</h3><p>${done.toLocaleString('fa-IR')} از ۲۰ مرحله تمام شده</p><div class="progress-track"><span style="width:${percent}%"></span></div><button class="btn primary" data-unit="${u.unit_id}">ورود به محله</button></div></article>`;}
function renderUnit(unitId){const u=unitById[unitId];if(!u)return;const c=cityByCode(u.book_code);current.screen='unit';current.city=c;current.unit=u;const p=unitProgress(unitId);const done=p.done||{};const stages=Array.from({length:20},(_,i)=>{let n=i+1,open=n===1||n<=(p.unlocked||1),complete=!!done[n];return `<button class="stage-card ${open?'':'locked'} ${complete?'done':''}" data-stage="${n}" ${open?'':'disabled'} aria-label="مرحله ${n}"><img src="${imgStage(n)}" alt="تصویر مرحله ${n}"><strong>مرحله ${n.toLocaleString('fa-IR')}</strong><small>${complete?'تمام‌شده':open?'باز':'قفل است'}</small></button>`}).join('');
main.innerHTML=`<section class="view"><div class="row" style="margin-top:12px"><button class="btn ghost" id="backCity">← بازگشت به شهر ${esc(c.name)}</button><button class="btn ghost" id="backMap">نقشهٔ ایران</button></div><div class="panel"><div class="city-banner"><div><span class="pill">${esc(c.book)}</span><h2>محلهٔ ${u.unit_no.toLocaleString('fa-IR')}: ${esc(u.title)}</h2><p>هر مرحله ۲۰ سؤال دارد و فقط از همین درس پرسیده می‌شود.</p></div><img src="${imgLesson(u)}" alt="تصویر اختصاصی محله"></div><div class="progress-track"><span style="width:${Math.round(Object.keys(done).length/20*100)}%"></span></div><p class="subtext">مرحله‌های تمام‌شده: ${Object.keys(done).length.toLocaleString('fa-IR')} از ۲۰</p><div class="stage-grid">${stages}</div></div></section>`;
$('backCity').onclick=()=>renderCity(c.id);$('backMap').onclick=renderMap;main.querySelectorAll('[data-stage]').forEach(b=>b.addEventListener('click',()=>startStage(unitId,Number(b.dataset.stage))));}
function deterministicShuffle(arr,seed){let a=arr.slice(),x=(seed>>>0)||1234567;for(let i=a.length-1;i>0;i--){x=(1664525*x+1013904223)>>>0;let j=x%(i+1);[a[i],a[j]]=[a[j],a[i]];}return a;}
function startStage(unitId,stage){const u=unitById[unitId];if(!u)return;const p=unitProgress(unitId);if(stage>1&&stage>(p.unlocked||1)){showToast('ابتدا مرحلهٔ قبلی همین محله را تمام کن.');return;}const all=questionsByUnit[unitId]||[];if(all.length!==60){showToast('تعداد سؤال‌های این محله کامل نیست.');return;}const cycle=Math.floor((stage-1)/3),offset=((stage-1)%3)*20;const order=deterministicShuffle(all,unitId.split('').reduce((a,c)=>a+c.charCodeAt(0),0)+cycle*977);let chosen=order.slice(offset,offset+20);if(chosen.length!==20)chosen=order.slice(0,20);chosen=chosen.map((q,i)=>({...q,_options:deterministicShuffle(q.options,stage*31+i*17+unitId.length)}));current={screen:'quiz',city:cityByCode(u.book_code),unit:u,stage,items:chosen,index:0,answers:[],feedback:false,from:'unit'};renderQuestion();}
function renderQuestion(){const q=current.items[current.index],n=current.index+1,u=current.unit,c=current.city;current.screen='quiz';const selected=current.answers[current.index];const chosen=selected?selected.chosen:null;const options=q._options||q.options;
main.innerHTML=`<section class="view"><div class="row" style="margin-top:12px"><button class="btn ghost" id="quizBack">← خروج از مرحله</button><span class="pill">${esc(c.name)} • ${esc(c.book)}</span></div><div class="panel"><div class="quiz-head"><div><h2 class="section-title">محلهٔ ${u.unit_no.toLocaleString('fa-IR')}: ${esc(u.title)}</h2><p class="subtext">مرحلهٔ ${current.stage.toLocaleString('fa-IR')} — سؤال‌ها فقط از همین درس هستند.</p></div><div class="question-count">سؤال ${n.toLocaleString('fa-IR')} از ۲۰</div></div><div class="progress-track"><span style="width:${n/20*100}%"></span></div><div class="question-art"><img src="${imgLesson(u)}" alt="تصویر محله"><div><b>${esc(c.title)}</b><br>${esc(u.title)}<br><span class="tiny">هر پاسخ درست، یک قدم به سوی دانایی</span></div><img src="${imgStage(current.stage)}" alt="تصویر مرحله" style="width:66px;height:66px;object-fit:contain;border:0;background:transparent"></div><div class="question-text">${esc(q.question)}</div><div class="options">${options.map((opt,i)=>{let cls='option';if(selected){if(opt===q.correct_answer)cls+=' correct';else if(opt===chosen)cls+=' wrong';}return `<button class="${cls}" data-option="${i}" ${selected?'disabled':''}><span class="letter">${['الف','ب','ج','د'][i]}</span>${esc(opt)}</button>`}).join('')}</div>${selected?`<div class="feedback ${selected.correct?'good':'bad'}"><strong>${selected.correct?'آفرین! پاسخ درست است.':'اشکالی ندارد؛ از اشتباه هم یاد می‌گیریم.'}</strong>${selected.correct?'':`<div>پاسخ درست: <b>${esc(q.correct_answer)}</b></div>`}<div>${esc(q.explanation||'به متن درس برگرد و نکتهٔ مهم را دوباره مرور کن.')}</div>${q.hint?`<div class="tiny">راهنمایی: ${esc(q.hint)}</div>`:''}</div><div class="quiz-footer"><button class="btn primary" id="nextQuestion">${n===20?'دیدن کارنامه':'سؤال بعدی'} ←</button></div>`:''}</div></section>`;
$('quizBack').onclick=handleExitAttempt;main.querySelectorAll('[data-option]').forEach(b=>b.addEventListener('click',()=>chooseAnswer(Number(b.dataset.option))));if(selected)$('nextQuestion').onclick=nextQuestion;}
function chooseAnswer(index){if(current.answers[current.index])return;const q=current.items[current.index],opt=(q._options||q.options)[index];current.answers[current.index]={chosen:opt,correct:opt===q.correct_answer};renderQuestion();}
function nextQuestion(){if(current.index<19){current.index++;renderQuestion();}else renderReport();}
function renderReport(){const u=current.unit,c=current.city,answers=current.answers;const correct=answers.filter(a=>a&&a.correct).length,wrong=20-correct,percent=Math.round(correct/20*100);const old=unitProgress(u.unit_id),p=getProgress(),done=old.done||{},best=old.best||{};done[current.stage]=true;best[current.stage]=Math.max(best[current.stage]||0,percent);p[u.unit_id]={unlocked:Math.max(old.unlocked||1,Math.min(20,current.stage+1)),done,best};saveProgress(p);current.screen='report';const msg=percent>=90?'درخشان بودی! با تلاش و دقت به این نتیجه رسیدی.':percent>=70?'آفرین! با کمی تمرین بیشتر قوی‌تر می‌شوی.':percent>=50?'خوب تلاش کردی؛ پاسخ‌های توضیح‌داده‌شده را دوباره بخوان.':'ناامید نشو؛ هر اشتباه فرصتی برای یادگیری است. یک بار دیگر تمرین کن.';const missed=answers.map((a,i)=>({a,q:current.items[i],i})).filter(x=>!x.a||!x.a.correct);
main.innerHTML=`<section class="view"><div class="panel"><div class="result-hero"><img class="result-medal" src="${imgStage(Math.max(1,Math.min(20,Math.ceil(percent/5)) ))}" alt="نشان نتیجه"><div><h2>کارنامهٔ مرحلهٔ ${current.stage.toLocaleString('fa-IR')}</h2><p>${esc(msg)}<br>${esc(c.name)} • ${esc(u.title)}</p></div></div><div class="score-grid"><div class="score-box"><strong>${percent.toLocaleString('fa-IR')}٪</strong><small>درصد موفقیت</small></div><div class="score-box"><strong>${correct.toLocaleString('fa-IR')}</strong><small>پاسخ درست</small></div><div class="score-box"><strong>${wrong.toLocaleString('fa-IR')}</strong><small>نیازمند مرور</small></div></div><div class="panel" style="margin-top:12px"><h3 class="section-title">پاسخ‌ها و توضیح آموزشی</h3><p class="subtext">پاسخ‌های اشتباه را با جواب درست و توضیحشان مرور کن. این مرحله ذخیره شد و مرحلهٔ بعدی همین محله باز است.</p><div class="review-list">${missed.length?missed.map(({a,q,i})=>`<article class="review-item"><h4>سؤال ${ (i+1).toLocaleString('fa-IR') }: ${esc(q.question)}</h4><div>پاسخ تو: <span style="color:#9c3c32">${esc(a?a.chosen:'بدون پاسخ')}</span></div><div>پاسخ درست: <span class="correct-answer">${esc(q.correct_answer)}</span></div><div>${esc(q.explanation||'برای تثبیت یادگیری، این بخش از درس را دوباره بخوان.')}</div></article>`).join(''):'<div class="feedback good"><strong>همهٔ پاسخ‌ها درست بودند!</strong>کارت عالی بود؛ به همین روش ادامه بده.</div>'}</div></div><div class="row"><button class="btn primary" id="nextStage">${current.stage<20?'رفتن به مرحلهٔ بعد':'مرور دوبارهٔ محله'} ←</button><button class="btn" id="sameUnit">بازگشت به محله</button><button class="btn ghost" id="cityHome">بازگشت به شهر</button></div></div></section>`;
$('nextStage').onclick=()=>{if(current.stage<20)startStage(u.unit_id,current.stage+1);else renderUnit(u.unit_id)};$('sameUnit').onclick=()=>renderUnit(u.unit_id);$('cityHome').onclick=()=>renderCity(c.id);}
let exitAttempt=0;
function handleExitAttempt(){if(current.screen==='quiz'){exitAttempt++;if(exitAttempt===1){showModal('عه!!!مثل اینکه اشتباهی دستت خورده روی خروج،اگر مطمئنی دوباره تکرار کن','ادامهٔ مرحله','بازگشت به سؤال‌ها',()=>{modalHost.innerHTML='';});return;}exitAttempt=0;showModal('از این مرحله خارج می‌شوی. پاسخ‌های این مرحله ثبت نمی‌شوند.','خروج از مرحله','ماندن در مرحله',()=>renderUnit(current.unit.unit_id));return;}if(current.screen==='map'){showModal('خب انگار داری از سرزمین دانایی خارج میشی،اگر مطمئنی دوباره خروج رو بزن،به امید دیدار دوباره','خروج از برنامه','ادامهٔ بازی',()=>{if(window.AndroidVoice&&AndroidVoice.closeApp)AndroidVoice.closeApp();else showToast('برای بستن برنامه از دکمهٔ بازگشت گوشی استفاده کن.');});return;}if(current.screen==='report'){renderUnit(current.unit.unit_id);return;}if(current.city){renderMap();return;}renderMap();}
function showModal(text,ok,cancel,onOk){modalHost.innerHTML=`<div class="modal-backdrop"><div class="modal"><h2>سرزمین دانایی</h2><p>${esc(text)}</p><div class="row"><button class="btn danger" id="modalOk">${esc(ok)}</button><button class="btn primary" id="modalCancel">${esc(cancel)}</button></div></div></div>`;$('modalOk').onclick=()=>{modalHost.innerHTML='';onOk&&onOk()};$('modalCancel').onclick=()=>modalHost.innerHTML='';}
function handleBackButton(){handleExitAttempt();}
$('homeBtn').onclick=()=>{if(current.screen==='map')showToast('اکنون روی نقشهٔ ایران هستی.');else renderMap()};$('soundBtn').onclick=()=>{$('musicPlayer').classList.remove('hidden');$('musicReopen').classList.add('hidden');};

// Music player: bundled tracks + Android system document picker for local audio files
const music=$('musicAudio'),tracks=['music/background-01.mp3','music/background-02.mp3'];let trackIndex=0,chosenObjectUrl=null,muted=false,volume=.65;
function loadTrack(i){trackIndex=(i+tracks.length)%tracks.length;if(chosenObjectUrl){URL.revokeObjectURL(chosenObjectUrl);chosenObjectUrl=null;}music.src=tracks[trackIndex];$('musicName').textContent='آهنگ '+(trackIndex+1).toLocaleString('fa-IR');music.load();}
function playMusic(){music.play().then(()=>showToast('موسیقی در حال پخش است.')).catch(()=>showToast('برای شروع موسیقی دوباره دکمهٔ پخش را لمس کن.'));}
$('musicPlay').onclick=playMusic;$('musicPause').onclick=()=>music.pause();$('musicStop').onclick=()=>{music.pause();music.currentTime=0};$('musicPrev').onclick=()=>{loadTrack(trackIndex-1);playMusic()};$('musicNext').onclick=()=>{loadTrack(trackIndex+1);playMusic()};$('musicMute').onclick=()=>{muted=!muted;music.muted=muted;$('musicMute').textContent=muted?'صدا +':'صدا ×';$('musicMute').title=muted?'وصل صدا':'قطع صدا'};
function setVol(v){volume=Math.max(0,Math.min(1,v));music.volume=volume;$('volumeRange').value=volume;$('volumeLabel').textContent=Math.round(volume*100).toLocaleString('fa-IR')+'٪';} $('volumeRange').oninput=e=>setVol(Number(e.target.value));$('volDown').onclick=()=>setVol(volume-.1);$('volUp').onclick=()=>setVol(volume+.1);$('musicPick').onclick=()=>{$('musicFile').click()};$('musicFile').onchange=e=>{const f=e.target.files&&e.target.files[0];if(!f)return;if(!f.type.startsWith('audio/')&&!/\.(mp3|m4a|aac|ogg|wav|flac)$/i.test(f.name)){showToast('این فایل صوتی شناخته نشد.');return;}if(chosenObjectUrl)URL.revokeObjectURL(chosenObjectUrl);chosenObjectUrl=URL.createObjectURL(f);music.src=chosenObjectUrl;$('musicName').textContent=f.name;playMusic();e.target.value='';};music.onended=()=>{if(!chosenObjectUrl){loadTrack(trackIndex+1);playMusic()}};$('musicClose').onclick=()=>{$('musicPlayer').classList.add('hidden');$('musicReopen').classList.remove('hidden')};$('musicReopen').onclick=()=>{$('musicPlayer').classList.remove('hidden');$('musicReopen').classList.add('hidden')};setVol(volume);loadTrack(0);

// Mandatory intro sequence: Bismillah -> Imam Khomeini -> Imam Khamenei -> user-provided Earth video -> map.
const introVideo=$('introVideo'),introAudio=$('introAudio');let introFinished=false,introStep=0,introTimer=null;
const introSteps=[
 {kind:'video',src:'video/bismillah_glow.mp4',title:'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',sub:'به نام خداوند بخشنده و مهربان'},
 {kind:'image',src:'images/intro/imam_khomeini.jpg',title:'امام خمینی (ره)',sub:'امید من به شما دبستانی‌هاست',duration:4200},
 {kind:'image',src:'images/intro/imam_khamenei.jpg',title:'امام خامنه‌ای',sub:'با دانایی، تلاش و امید پیش برو'},
 {kind:'video',src:'video/earth_from_space.mp4',title:'از زمین تا سرزمین دانایی',sub:'با چشم‌های کنجکاو، جهان را تماشا کن'}
];
function showIntroStep(index){if(introFinished)return;if(index>=introSteps.length){finishIntro();return;}introStep=index;clearTimeout(introTimer);introAudio.pause();const step=introSteps[index];$('introTitle').textContent=step.title;$('introSub').textContent=step.sub;$('introStart').classList.add('hidden');$('introState').textContent='مقدمه در حال پخش است…';const frame=$('introFrame');
 if(step.kind==='image'){introVideo.pause();frame.innerHTML=`<img class="intro-portrait" src="${step.src}" alt="${step.title}">`;introTimer=setTimeout(()=>showIntroStep(index+1),step.duration||4200);return;}
 frame.innerHTML='<video id="introVideo" class="intro-video" autoplay playsinline preload="auto"></video>';const v=$('introVideo');v.src=step.src;v.playsInline=true;v.onended=()=>showIntroStep(index+1);v.onerror=()=>{ $('introState').textContent='پخش این بخش خودکار انجام نشد؛ برای ادامه دکمه را لمس کن.';$('introStart').classList.remove('hidden');};const play=v.play();if(play&&play.catch)play.catch(()=>{ $('introState').textContent='برای پخش این بخش، دکمهٔ ادامه را لمس کن.';$('introStart').classList.remove('hidden');});
}
function finishIntro(){if(introFinished)return;introFinished=true;clearTimeout(introTimer);introAudio.pause();$('introScreen').classList.add('hidden');renderMap();}
function startIntro(){if(introStep>=introSteps.length){finishIntro();return;}showIntroStep(introStep);}
$('introStart').onclick=()=>{if(introStep===0&&introAudio.paused){introAudio.currentTime=0;introAudio.play().catch(()=>{});}startIntro();};
// The first Bismillah video also plays the bundled Bismillah audio when the device allows it.
setTimeout(()=>{showIntroStep(0);introAudio.play().catch(()=>{$('introState').textContent='برای شنیدن صدای بسم‌الله، یک بار صفحه را لمس کن.';$('introStart').classList.remove('hidden');});},180);
window.handleBackButton=handleBackButton;window.onVoiceResult=text=>showToast('صدای تشخیص‌داده‌شده: '+text);window.onVoiceError=()=>showToast('تشخیص صدا در این دستگاه در دسترس نیست.');
setTimeout(startIntro,180);// ... (خطوط قبلی فایل شما)
setTimeout(startIntro, 180);

// ============ دکمه راهنما ============
function showGuide() {
    let guideText = "پسرم دقت کن که این یک بازی برای پیشرفت درسی تو هست، هیچ مرحله‌ای باز نمیشه مگر اینکه مرحله قبل رو با موفقیت پشت سر گذاشته باشی، پس دقت کن که در همه مراحل موفق بشی. دوستت دارم بابایی شهاب.";
    showModal(guideText, 'راهنمای بازی', () => {}, () => {});
}

// ============ دکمه کلید مراحل ============
function renderStages() {
    let currentUnitId = current.unit ? current.unit.id : null;
    if (!currentUnitId) {
        showToast('ابتدا یک شهر و درس را انتخاب کنید.');
        return;
    }

    let unit = unitById[currentUnitId];
    let progress = unitProgress(currentUnitId);
    let stages = unit.stages || 20; 

    let html = `<section class="view"><div class="row"><button class="btn ghost" id="backToMap">← بازگشت به نقشه</button></div>`;
    html += `<div class="panel"><h2>کلید مراحل: ${esc(unit.book)} - ${esc(unit.title)}</h2><div class="stages-grid">`;

    for (let i = 1; i <= stages; i++) {
        let isUnlocked = progress.unlocked >= i;
        let isDone = progress.done >= i;
        let icon = isDone ? '✅' : (isUnlocked ? '🔓' : '🔒');
        let statusClass = isDone ? 'done' : (isUnlocked ? 'unlocked' : 'locked');
        
        html += `<button class="stage-btn ${statusClass}" onclick="${isUnlocked ? `startStage('${currentUnitId}', ${i})` : `showToast('ابتدا مرحله ${i-1} را با موفقیت رد کنید.')`}">
            <span>${i}</span>
            <small>${icon}</small>
        </button>`;
    }

    html += `</div></div></section>`;
    main.innerHTML = html;
    $('backToMap').onclick = renderMap;
}

// ============ دکمه کارنامه ============
function renderReportCard() {
    let progress = getProgress();
    let html = `<section class="view"><div class="row"><button class="btn ghost" id="backToMap">← بازگشت به نقشه</button></div>`;
    html += `<div class="panel"><h2>کارنامه تحصیلی</h2>`;

    if (Object.keys(progress).length === 0) {
        html += `<p>هنوز هیچ مرحله‌ای را بازی نکرده‌اید. برای دیدن کارنامه، ابتدا یک مرحله را کامل کنید.</p>`;
    } else {
        html += `<table class="report-table" style="width:100%; text-align:right; border-collapse: collapse;">
            <tr style="background: #087da5; color: white;">
                <th style="padding: 10px;">درس</th>
                <th style="padding: 10px;">مراحل انجام‌شده</th>
                <th style="padding: 10px;">میانگین امتیاز</th>
            </tr>`;
        
        for (let unitId in progress) {
            let unit = unitById[unitId];
            if (!unit) continue;
            let p = progress[unitId];
            let avgScore = p.best ? (p.best / p.done * 100).toFixed(1) : 0;
            html += `<tr style="border-bottom: 1px solid #ccc;">
                <td style="padding: 10px;">${esc(unit.book)} - ${esc(unit.title)}</td>
                <td style="padding: 10px;">${p.done || 0} از ${unit.stages || 20}</td>
                <td style="padding: 10px;">${avgScore}%</td>
            </tr>`;
        }
        html += `</table>`;
    }

    html += `</div></section>`;
    main.innerHTML = html;
    $('backToMap').onclick = renderMap;
}

})(); // <--- این همان خط آخر است که باید بعد از کدهای جدید بیاید